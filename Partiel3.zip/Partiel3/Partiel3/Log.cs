﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace TP_1
{
    [Serializable]
    public class Log
    {
        public String Message { get; set; }
        public DateTime Date { get; set; }
        public String Niveau { get; set; }

        //C'est pour le serializer XML
        public Log(){}

        //Création du log
        public Log(String message, String niveau)
        {
            Message = message;
            Date = DateTime.Now;
            Niveau = niveau;
        }

        public override String ToString()
        {
            return $"Message du {Date} : {Message} || {Niveau}";
        }

        //Sauvegarde du log dans le fichier
        static public void SauvegarderFichierJSON(Log log)
        {
            var json = new List<Log>();

            //Vérification de l'existence du fichier
            var serializer = JsonSerializer.Create();
            if (File.Exists("Fichier.json"))
            {
                using (StreamReader sr = new StreamReader("Fichier.json"))
                {
                    using (JsonReader reader = new JsonTextReader(sr))
                    {
                        //Récupération du fichier
                        json = serializer.Deserialize<List<Log>>(reader);
                    }
                }
            }
            
            //Ajout du log en paramètre dans la liste
            json.Add(log);

            using (StreamWriter sw = new StreamWriter("Fichier.json"))
            {
                using (JsonWriter writer = new JsonTextWriter(sw))
                {
                    //Ecriture dans le fichier
                    serializer.Serialize(writer, json);
                }
            }

            Console.Out.WriteLine("Ecriture dans le fichier \"Fichier.json\"");
        }

        static public void JSONtoXML()
        {
            if (File.Exists("Fichier.json"))
            {
                var serializerJSON = JsonSerializer.Create();
                var serializerXML = new XmlSerializer(typeof(List<Log>));
                var liste = new List<Log>();

                using (StreamReader sr = new StreamReader("Fichier.json"))
                {
                    using (JsonReader reader = new JsonTextReader(sr))
                    {
                        liste = serializerJSON.Deserialize<List<Log>>(reader);
                    }
                }

                using (StreamWriter sw = new StreamWriter("Fichier.xml"))
                {
                    serializerXML.Serialize(sw, liste);
                }

                Console.Out.WriteLine("Ecriture du fichier \"Fichier.json\" vers le fichier \"Fichier.xml\"");
            }else
            {
                Console.Out.WriteLine("Il n'y avait pas de fichier JSON à convertir :c");
            }
        }

        static public void Afficher(DateTime date)
        {
            var serializer = new XmlSerializer(typeof(List<Log>));
            if (File.Exists("Fichier.xml"))
            {
                var liste = new List<Log>();
                using (StreamReader sr = new StreamReader("Fichier.xml"))
                {
                    liste = serializer.Deserialize(sr) as List<Log>;
                }

                foreach(var log in liste)
                {
                    if(DateTime.Compare(log.Date, date) < 0)
                        Console.Out.WriteLine(log.ToString());
                }
            }
            else
            {
                Console.Out.WriteLine("Il n'existe aucun fichier XML, je ne peux pas l'afficher :c");
            }
        }
    }
}
