﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP_1
{
    public delegate void ChangementDispoDelegate(String titre, Boolean dispo);

    class Program
    {
        static void Main(string[] args)
        {
            bool fin = false;
            String reponse;

            //Menu
            do
            {
                Console.Out.WriteLine("1- Ajouter un log");
                Console.Out.WriteLine("2- Créer XML depuis JSON");
                Console.Out.WriteLine("3- Afficher logs depuis XML");
                Console.Out.WriteLine("4- Quitter");

                reponse = Console.ReadLine();

                switch (reponse)
                {
                    case "1":
                        String message;
                        Console.Write("Message : ");
                        message = Console.ReadLine();

                        String niveau;
                        Console.Write("Niveau : ");
                        niveau = Console.ReadLine();

                        Log.SauvegarderFichierJSON(new Log(message, niveau));
                        break;

                    case "2":
                        Log.JSONtoXML();
                        break;

                    case "3":
                        int jourInt, moisInt, anneeInt;

                        String jour;
                        Console.Write("Jour : ");
                        jour = Console.ReadLine();

                        String mois;
                        Console.Write("Mois : ");
                        mois = Console.ReadLine();

                        String annee;
                        Console.Write("Annee : ");
                        annee = Console.ReadLine();

                        if (Int32.TryParse(jour, out jourInt) && Int32.TryParse(mois, out moisInt) && Int32.TryParse(annee, out anneeInt))
                        {
                            Log.Afficher(new DateTime(anneeInt, moisInt, jourInt));
                        }else
                        {
                            Console.Out.WriteLine("La date est invalide !");
                        }

                        break;

                    case "4":
                        fin = true;
                        break;

                    default:
                        Console.WriteLine("Veillez à ne saisir qu'un chiffre entre 1 et 4 !");
                        break;
                }

                Console.ReadLine();
                Console.Clear();
            } while (!fin);
        }
    }
}